package MyTestModule;

our $FILENAME = __FILE__;

1;
